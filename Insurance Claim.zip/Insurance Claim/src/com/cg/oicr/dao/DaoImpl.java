package com.cg.oicr.dao;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Users;
import com.cg.oicr.exception.InsuranceException;
import com.cg.oicr.util.DBconnection;

public class DaoImpl implements IDao {
	
	
	Logger logger=Logger.getRootLogger();
	public DaoImpl()
	{
	PropertyConfigurator.configure("Resources//log.properties");
	
	}
	
	/*******************************************************************************************************
		 - Function Name	:	Login(Users user )
		 - Input Parameters	:	Users user
		 - Return Type		:	String
		 - Throws			:  	SQLException, IOException, InsuranceException
		 - Author			:	Team A
		 - Creation Date	:	8/1/2019
		 - Description		:	Login to insurance portal.
		 ********************************************************************************************************/
	@Override
	public String Login(Users user) throws SQLException, IOException, InsuranceException {
		String uname=null;
		String pwd=null;
		String rolecode=null;
		
		String username=user.getUsername();
		String password=user.getPassword();
		try {
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		Statement stm=connection.createStatement();
		ResultSet rs=stm.executeQuery(QueryMapper.USER_DETAILS);
		while(rs.next()){
			uname=rs.getString(1);
			pwd=rs.getString(2);
			
			if(username.equals(uname)&&password.equals(pwd)){
				uname=username;
				pwd=password;
				break;
			}
			
			uname=null;
			pwd=null;
		}
	
		PreparedStatement pst=connection.prepareStatement(QueryMapper.ROLECODE);
		pst.setString(1,uname);
		pst.setString(2,pwd);
	
		ResultSet rs1=pst.executeQuery();
		while(rs1.next()) {
			
			rolecode=rs1.getString(1);
			
			
		}
		
		if(rs1==null)
		{
			logger.error("login failed ");
			throw new InsuranceException("login again ");
		}
		else
		{
			logger.info("login done successfully:");
		}
		}catch(Exception e) {
			logger.fatal("Exception at login");
		}
		
		return rolecode;
		
	}

	/*******************************************************************************************************
	 - Function Name	:	List questions(int a)
	 - Input Parameters	:	int a
	 - Return Type		:	List
	 - Throws			:  	ClassNotFoundException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Display the questions.
	 ********************************************************************************************************/
	

	@Override
	public List questions(int a) throws ClassNotFoundException, IOException, InsuranceException {
		
		List li=new ArrayList();
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		PreparedStatement pS=null;
		ResultSet rs=null;
			try {
						
				switch(a) {
				case 1:
								
					pS=connection.prepareStatement(QueryMapper.QUESTION_ONE);
					rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 2:	
					pS=connection.prepareStatement(QueryMapper.QUESTION_TWO);
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
				case 3:
					
					 pS=connection.prepareStatement(QueryMapper.QUESTION_THREE);
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 4:
					 pS=connection.prepareStatement(QueryMapper.QUESTION_FOUR);
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 5:
					 pS=connection.prepareStatement(QueryMapper.QUESTION_FIVE);
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
				}	
				if(rs==null)
				{
					logger.error(" failed retrieving the questions");
					

				}
				else
				{
					logger.info("questions displayed successfully:");
				}
					
				connection.close();
				rs=null;
				pS=null;
		}catch(SQLException e){
			
			logger.fatal("Exception at question");
			throw new InsuranceException("try again ");
			}
						
			return li;
	
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	insert(long q, int b, String id)
	 - Input Parameters	:	long q, int b, String id
	 - Return Type		:	int
	 - Throws			:   SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Inserting the details into policy.
	 ********************************************************************************************************/
	
	

	@Override
	public int insert(long q, int b, String id) throws SQLException, IOException, InsuranceException {
		String answer=null;
		int count=0;
		
		switch(b)
		{
		case 1:
			answer="yes";
			count+=1;
			break;
		case 2:
			answer="no";
			break;
		}
		try {
			int queryResult=0;
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();	
		PreparedStatement ps1=connection.prepareStatement(QueryMapper.INSERT_POLICY_DETAILS);
		ps1.setLong(1,q);
		ps1.setString(2,id);
		ps1.setString(3,answer);
		queryResult=ps1.executeUpdate();
		
		if(queryResult==0)
		{
			logger.error("Policy Details  inserting failed");
			throw new InsuranceException("try again ");

		}
		else
		{
			
			logger.info("Policy Details inserted successfully:");
			
			
		}
		connection.close();
		ps1.close();
		
				
		} catch (Exception e) {
			
			logger.fatal("Exception at ");
			throw new InsuranceException("try again insert Policy");
		}
		
		
		return count;
	}

	
	/*******************************************************************************************************
	 - Function Name	:	addHisCustomer(String user, String agent)
	 - Input Parameters	:	String user, String agent
	 - Return Type		:	String
	 - Throws			:   SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Adding customer details into agent.
	 ********************************************************************************************************/
	@Override
	public String addHisCustomer(String user, String agent) throws IOException, SQLException, InsuranceException {
		String user1=user;
		String user2=null;
		String ack=null;
		int queryResult=0;
		try {
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
			
		Statement statement=connection.createStatement();
		ResultSet rs=statement.executeQuery(QueryMapper.RETRIVE_USERNAME);
		while(rs.next())
		{
			user2=rs.getString(1);
			if(user2.equals(user1)){
				
					PreparedStatement pS=connection.prepareStatement(QueryMapper.INSERT_AGENT_USER);
					pS.setString(1,agent);
					pS.setString(2,user1);
					queryResult=pS.executeUpdate();
					ack="Values inserted";
					break;
				
			}
			}
		if(queryResult==0)
		{
			logger.error(" Adding his customer failed");
			

		}
		else
		{
			logger.info("Added his customer successfully:");
		}
		connection.close();
		statement.close();
		rs.close();
		}catch(Exception e) {
			logger.fatal("Exception at addHisCustomer");
			throw new InsuranceException("try again ");
		}
		
		
		return ack;

	}
	
	/*******************************************************************************************************
	 - Function Name	:	getPolicyDetails(String name)
	 - Input Parameters	:	String name
	 - Return Type		:	List
	 - Throws			:   SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Retrieving policy details.
	 ********************************************************************************************************/

	@Override
	public List getPolicyDetails(String name) throws InsuranceException {
		
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		List p=new ArrayList();
		String name1=null;
		ResultSet rs1=null;
		PolicyDetails policy=null;
		try {
		Connection con=DBconnection.getConnection();
		String name2=name;
		
		ps=con.prepareStatement(QueryMapper.RETRIVE_USERNAME);
		
		rs=ps.executeQuery();
		while(rs.next())
			{
				 name1=rs.getString(1);
				 if(name1.equals(name2))
				 {
			        ps=con.prepareStatement(QueryMapper.RETRIVE_POLICIES);	
		            ps.setString(1,name2);
		            rs1=ps.executeQuery();
			        break;
				 }
		       name1=null;
		    }
					
		while(rs1.next())
		{
			
			policy=new PolicyDetails();
			policy.setPolicy_Number(rs1.getLong(1));	
			policy.setPolicy_Premium(rs1.getFloat(2));
			policy.setAccount_number(rs1.getLong(3));
			p.add(policy);		
		}
		if(rs1==null)
		{
			logger.error(" Policy Details retrieving failed");
			

		}
		else
		{			
			logger.info("Policy Details retrieved successfully:");
		}
		
		con.close();
		ps.close();
		rs.close();
		
		}
		catch(Exception e)
		{
			logger.fatal("Exception at get policy details");
			throw new InsuranceException("Exception at policy details");
			
		}

		 return p;
			
	}
	
	/*******************************************************************************************************
	 - Function Name	:	createClaim(Claim claim, PolicyDetails policy)
	 - Input Parameters	:	Claim claim, PolicyDetails policy
	 - Return Type		:	long
	 - Throws			:   SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Claim Creation.
	 ********************************************************************************************************/

	@Override
	public long createClaim(Claim claim, PolicyDetails policy) throws IOException, SQLException, InsuranceException {
		long claimNo=0;
		Connection connection=null;
		PreparedStatement pS=null;
		Statement s=null;
		ResultSet rs=null;
		try {
		DBconnection db=new DBconnection();
		 connection=db.getConnection();
		
		pS=connection.prepareStatement(QueryMapper.INSERT_CLAIM);
		pS.setString(1,claim.getClaim_Reason());
		pS.setString(2,claim.getAccident_Location_Street());
		pS.setString(3,claim.getAccident_City());
		pS.setString(4, claim.getAccident_State());
		pS.setInt(5, claim.getAccident_Zip());
		pS.setString(6, claim.getClaim_Type1());
		pS.setLong(7,policy.getPolicy_Number());
		pS.executeUpdate();
		
		 s=connection.createStatement();
		 rs=s.executeQuery(QueryMapper.RETRIVE_CURRVAL);
		while(rs.next())
		{
			 claimNo=rs.getLong(1);
		}
		
		if(rs==null)
		{
			logger.error(" claim creation failed");
			throw new InsuranceException("try again ");
			
		}
		else
		{
			logger.info("claim created successfully:");
		}
					
		
		}
		catch(Exception e)
		{
			logger.fatal("Excetion at claim creation");
			throw new InsuranceException("try again ");
			
		}
		finally {
			rs.close();
			connection.close();
			pS.close();

		}
		return claimNo;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addDetails(Users user)
	 - Input Parameters	:	Users user
	 - Return Type		:	boolean
	 - Throws			:   SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Adding details into user.
	 ********************************************************************************************************/


	@Override
	public boolean addDetails(Users user) throws ClassNotFoundException, SQLException, InsuranceException, IOException {
		
		boolean boo=false;
		Connection connection = DBconnection.getConnection();	
		String dumm=user.getUsername();
		PreparedStatement preparedStatement=null;			
		
		try
		{	
			String username=null;
			preparedStatement=connection.prepareStatement(QueryMapper.RETRIVE_USERNAME);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				username=resultSet.getString(1);
				if(dumm.equals(username))
				{
					
					break;
				}
				
			}
			if(!user.getUsername().equals(username)){
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_USER);
            preparedStatement.setString(1,user.getUsername());			
			preparedStatement.setString(2,user.getPassword());
			preparedStatement.setString(3,user.getRollcode());
			preparedStatement.executeUpdate();
			boo=true;
			}
			else
			{
				boo=false;
			}
			connection.close();
			preparedStatement.close();
			resultSet.close();
	}catch(Exception e) {
		
		logger.fatal("Exception at Add details");
		throw new InsuranceException("try again ");
		
	}
		
		if(boo==false)
		{
			logger.error(" Profile Creation failed");
			
		}
		else
		{
		logger.info("Profile Created successfully:");
		}
		return boo;				
}
	
	/*******************************************************************************************************
	 - Function Name	:	viewClaim(long claimNo)
	 - Input Parameters	:	long claimNo
	 - Return Type		:	List
	 - Throws			:   ClassNotFoundException,SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Retrieving claim details.
	 ********************************************************************************************************/
	
	@Override
	public List viewClaim(long claimNo) throws ClassNotFoundException, SQLException, InsuranceException, IOException  {
		Connection connection=DBconnection.getConnection();
		PreparedStatement st=null;
		 List list=new ArrayList();
		long a=claimNo;
		
		try
		{      
			
		st=connection.prepareStatement(QueryMapper.RETRIVE_CLAIM);
		st.setLong(1, a);
		ResultSet resultSet = st.executeQuery();
				
			while(resultSet.next())
			{				
			list.add(resultSet.getLong(1));
			list.add(resultSet.getLong(2));
			list.add(resultSet.getString(3));
			}
			connection.close();
			st.close();
			resultSet.close();
		}catch(Exception e)
		{
			
			logger.fatal("Exception at view claim");
			throw new InsuranceException("try again ");
		}
		if(list.isEmpty())
		{
			logger.error("list empty at view claim");
		}
		else
		{
			logger.info("View CLaim successfull");
		}
		
		return list;
	}	
	
	/*******************************************************************************************************
	 - Function Name	:	checkUser(String user,String agent)
	 - Input Parameters	:	String user,String agent
	 - Return Type		:	boolean
	 - Throws			:   ClassNotFoundException,SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Check the role whether agent or user.
	 ********************************************************************************************************/

	@Override
	public boolean checkUser(String user,String agent) throws ClassNotFoundException, IOException, SQLException, InsuranceException {
		Connection connection=DBconnection.getConnection();
		PreparedStatement st=null;
		String user1=null;
		boolean boo=false;
		try {
		st=connection.prepareStatement(QueryMapper.CHECK_AGENT_USER);
		st.setString(1,agent);
		ResultSet rs=st.executeQuery();
		while(rs.next())
		{
			
			user1=rs.getString(1);
			if(user.equals(user1)){
				user1=user;
				boo=true;
				break;
			}
			user1=null;
		}
		}catch(Exception e){
			logger.fatal("Exception at checkuser");
			throw new InsuranceException("try again ");
		}
		if(boo==true) {
			logger.info("correct info");
		}else {
			logger.info("incorrect info");
		}
		
		return boo;
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	genReport(long claimNo)
	 - Input Parameters	:	long claimNo
	 - Return Type		:	List
	 - Throws			:   ClassNotFoundException,SQLException, IOException, InsuranceException
	 - Author			:	Team A
	 - Creation Date	:	8/1/2019
	 - Description		:	Report Generation.
	 ********************************************************************************************************/


	@Override
	public List genReport(long claimNo)throws ClassNotFoundException, IOException, SQLException, InsuranceException  {
		List list=new ArrayList();
		PreparedStatement prepareStatement=null;
		ResultSet resultSet=null;
		long policyno=0;
		try {
		Connection connection=DBconnection.getConnection();
		prepareStatement=connection.prepareStatement(QueryMapper.RETRIVE_CLAIM_DETAILS);
		prepareStatement.setLong(1,claimNo);
		resultSet=prepareStatement.executeQuery();
		while(resultSet.next()) {
			list.add(resultSet.getString(2));
			list.add(resultSet.getString(3));
			list.add(resultSet.getString(4));
			list.add(resultSet.getString(5));
			list.add(resultSet.getInt(6));
			list.add(resultSet.getString(7));
			policyno=resultSet.getLong(8);
		}
	
		PreparedStatement prepareStatement1=connection.prepareStatement(QueryMapper.RETRIVE_POLICY_DETAILS);
		prepareStatement1.setLong(1,policyno);
		ResultSet resultSet1=prepareStatement1.executeQuery();
		while(resultSet1.next()) {
		list.add(resultSet1.getString(1));
		list.add(resultSet1.getString(2));
		}	
		connection.close();
		prepareStatement.close();
		prepareStatement1.close();
		resultSet.close();
		resultSet1.close();
		}catch(SQLException s){
			
			logger.fatal("Exception at genReport");
			throw new InsuranceException("try again ");
		}
		if(list.isEmpty()) {
			logger.error("at gen report");
		}else {
			logger.info("report done successfully");
		}
		
		
		
		return list;
	}

}