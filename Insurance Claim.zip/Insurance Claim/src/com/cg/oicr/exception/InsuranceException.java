package com.cg.oicr.exception;

public class InsuranceException extends Exception {

	public InsuranceException(String message) {
		super("enter correct input");
		
	}
	
	

}
